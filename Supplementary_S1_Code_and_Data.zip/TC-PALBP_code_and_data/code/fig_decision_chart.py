"""Managerial decision chart (Figure 4): turns the rules of Section 7 into a procedure."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon

INK, INK2, LINE = "#0b0b0b", "#52514e", "#8a8984"
BLUE, GREEN, AMBER, GREY = "#e3eefb", "#e2f4ec", "#fdf1d6", "#f1f0ec"
fig, ax = plt.subplots(figsize=(7.2, 8.6)); ax.set_xlim(0, 100); ax.set_ylim(0, 118); ax.axis("off")

def box(x, y, w, h, title, text, fc):
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0.4,rounding_size=1.6",
                                fc=fc, ec=LINE, lw=0.9))
    ax.text(x, y + h / 2 - 2.6, title, ha="center", va="top", fontsize=8.6, weight="bold", color=INK)
    ax.text(x, y + h / 2 - 6.4, text, ha="center", va="top", fontsize=7.3, color=INK2, linespacing=1.35)

def diamond(x, y, w, h, text):
    ax.add_patch(Polygon([[x, y + h / 2], [x + w / 2, y], [x, y - h / 2], [x - w / 2, y]], closed=True, fc="white", ec=LINE, lw=0.9))
    ax.text(x, y, text, ha="center", va="center", fontsize=7.8, weight="bold", color=INK)

def arrow(x1, y1, x2, y2, label=None, lx=0, ly=0):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="-|>", color=LINE, lw=1.0, shrinkA=0, shrinkB=0))
    if label:
        ax.text((x1 + x2) / 2 + lx, (y1 + y2) / 2 + ly, label, fontsize=7.3, color=INK2, ha="center")

box(50, 111, 74, 11, "1  Measure human variability",
    "Time study: 30–50 cycles per operation, element times (Appendix B)\n→ mean time tᵢ, task CV cvᵢ, operator-pace CV cvₚ", BLUE)
arrow(50, 105.3, 50, 101)
box(50, 94.5, 74, 12.5, "2  Set takt and fix duplications",
    "T = available time / demand.  Every operation longer than the planning cycle\nneeds a duplicated station (and a second machine)", BLUE)
arrow(50, 88.1, 50, 86.0)
diamond(50, 80.5, 46, 11, "Validated simulator\nof the line available?")
ax.plot([27, 17], [80.5, 80.5], color=LINE, lw=1.0); arrow(17, 80.5, 17, 73.6)
ax.plot([73, 83], [80.5, 80.5], color=LINE, lw=1.0); arrow(83, 80.5, 83, 73.6)
ax.text(21, 81.6, "yes", fontsize=7.3, color=INK2, ha="center"); ax.text(79, 81.6, "no", fontsize=7.3, color=INK2, ha="center")
box(17, 65, 30, 16, "3a  TC-PALBP-V", "Learned constraint +\nsimulation check of every\ndesign; never worse than\nthe best uniform margin", GREEN)
box(83, 65, 30, 16, "3b  TC-PALBP-C", "Learned constraint with\n95% conformal margin;\nno simulation; met demand\nin 30/30 test cases", GREEN)
arrow(17, 56.6, 40, 47.5); arrow(83, 56.6, 60, 47.5)
box(50, 41, 80, 12, "4  Place slack only in the critical band",
    "Stations loaded within ≈3% (CV≈0.1) to ≈13% (CV≈0.3) of the bottleneck lose output;\ngive spare capacity to the most variable of them (e.g. trainees). Others need none.", AMBER)
arrow(50, 34.8, 50, 31)
box(50, 25, 80, 11, "5  Do not rely on duplication or position",
    "A duplicated station needs as much slack as a single one at the same load;\nmoving slack along the line changes output by < 0.4%", AMBER)
arrow(50, 19.3, 50, 15.5)
box(50, 9.5, 80, 11, "6  Re-balance after every improvement",
    "Lean/kaizen time savings release operators only after re-optimisation;\nlarger buffers (b ≥ 2) reduce the slack needed", GREY)
ax.text(50, 1.2, "Avoid: station-level chance constraints for buffered lines (4–5 extra operators; often infeasible)",
        ha="center", fontsize=7.3, color="#b3261e", style="italic")
fig.tight_layout(); fig.savefig("results/fig_decision_chart.png", dpi=300)
print("ok")
