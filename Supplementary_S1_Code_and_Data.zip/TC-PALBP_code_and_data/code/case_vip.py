"""VIP case-study runs (scenario S3_mixed unless stated): current line, buffer sensitivity,
lean scenario (11.7% measured work-content reduction), and the surrogate-loss curves.
Appends to results/case_results.jsonl"""
import json, time, pickle, math, sys
import numpy as np
import models
from models import solve_uniform, solve_chance, solve_tclb, des
from instances import vip_instance
from experiments import SCENARIOS, cv_vector, record
from sim import evaluate_design

f = open("results/case_results.jsonl", "a")
which = sys.argv[1] if len(sys.argv) > 1 else "all"
inst = vip_instance()
sc = SCENARIOS["S3_mixed"]; cvp = sc["cvp"]; cv = np.full(27, sc["cv_val"])
if which in ("all", "current"):
    for scn, s in SCENARIOS.items():
        import zlib; cvv = cv_vector(inst, s, seed=zlib.crc32(inst["name"].encode()) % 10000)
        x = evaluate_design(inst["t"], cvv, [[i] for i in range(27)], [1] * 27, b=2, reps=30, cvp=s["cvp"])
        from sim import lcb as _l; record(f, part="current", scenario=scn, ops=24, mean=float(x.mean()), lcb=_l(x))
if which in ("all", "lean"):
    lean = dict(inst); lean["t"] = np.round(inst["t"] * (1 - 0.117), 4); lean["name"] = "VIP-lean"
    for meth in ("UNIFORM_TUNED", "TCLB_V"):
        t0 = time.time()
        if meth == "UNIFORM_TUNED":
            for m in np.round(np.arange(0.0, 0.2, 0.01), 2):
                d = solve_uniform(lean, m, tl=30); e = des(lean, cv, d, 2, cvp=cvp)
                if e["feasible"]: break
        else:
            sur = pickle.load(open("runs/surrogate/surrogate_b2.pkl", "rb"))
            d = solve_tclb(lean, cv, sur, 2, tl=30, cvp=cvp, mode="V"); e = d["des"]
        record(f, part="lean", method=meth, ops=sum(d["r"]), des_mean=e["mean"], lcb=e["lcb"], feasible=e["feasible"],
               secs=time.time() - t0, stations=d["stations"], r=d["r"])
if which in ("all", "buffers"):
    for b in (1, 3, 5):
        sur = pickle.load(open(f"runs/surrogate/surrogate_b{b}.pkl", "rb"))
        for meth in ("UNIFORM_TUNED", "TCLB_V"):
            t0 = time.time()
            if meth == "UNIFORM_TUNED":
                for m in np.round(np.arange(0.0, 0.2, 0.01), 2):
                    d = solve_uniform(inst, m, tl=30); e = des(inst, cv, d, b, cvp=cvp)
                    if e["feasible"]: break
                extra = dict(margin=float(m))
            else:
                d = solve_tclb(inst, cv, sur, b, tl=30, cvp=cvp, mode="V"); e = d["des"]; extra = dict(Ubar=d["Ubar"])
            record(f, part="buffers", b=b, method=meth, ops=sum(d["r"]), des_mean=e["mean"], lcb=e["lcb"],
                   feasible=e["feasible"], secs=time.time() - t0, stations=d["stations"], r=d["r"], **extra)
print("done")
