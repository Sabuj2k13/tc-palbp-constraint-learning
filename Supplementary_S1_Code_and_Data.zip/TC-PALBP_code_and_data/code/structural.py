"""Direct simulation checks of the structural insights (no surrogate involved).
E1 pooling: bottleneck station single vs duplicated, same relative load and per-unit CV.
E2 position (bowl): where should slack go? Same total capacity, bottleneck/slack placed at
   the ends vs the middle. Output: results/structural.json"""
import json, numpy as np
from sim import evaluate_station_line, lcb
out = {}
K = 12; reps = 60
res = []
for cv in (0.1, 0.2, 0.3):
    for rho_other in (0.85, 0.9, 0.95):
        row = dict(cv=cv, rho_other=rho_other)
        for rb in (1, 2):
            r = np.ones(K, int); r[K // 2] = rb
            S = np.full(K, rho_other); S[K // 2] = 1.0 * rb
            x = evaluate_station_line(S, np.full(K, cv), r, b=2, reps=reps, seed0=5) / 480.0
            row[f"TH_r{rb}"] = float(x.mean())
        res.append(row); print(row, flush=True)
out["E1_pooling"] = res
# E2: 12 stations, 11 at rho=1 (cycle 1) and slack 'budget' delta=0.06 total distributed:
res = []
for cv in (0.15, 0.3):
    patterns = {
        "uniform": np.full(K, 1 - 0.06 / K),
        "ends": np.r_[1 - 0.03, np.ones(K - 2), 1 - 0.03],
        "middle(bowl)": np.r_[np.ones(K // 2 - 1), 1 - 0.03, 1 - 0.03, np.ones(K // 2 - 1)],
        "first_half": np.r_[np.full(K // 2, 1 - 0.01), np.ones(K // 2)],
        "second_half": np.r_[np.ones(K // 2), np.full(K // 2, 1 - 0.01)],
    }
    for name, S in patterns.items():
        x = evaluate_station_line(S, np.full(K, cv), np.ones(K, int), b=2, reps=reps, seed0=9) / 480.0
        row = dict(cv=cv, pattern=name, TH=float(x.mean()), cap=float(1 / S.max()))
        res.append(row); print(row, flush=True)
out["E2_position"] = res
json.dump(out, open("results/structural.json", "w"), indent=1)
