"""Analytical baseline: pairwise decomposition of a serial line with finite buffers.
Each adjacent pair (k, k+1) is treated as a two-station line with exponential-equivalent rates
mu = r/S and buffer positions K = b + 1, whose throughput has the closed form
    TH2 = mu1*mu2*(mu1^(K+1) - mu2^(K+1)) / (mu1^(K+2) - mu2^(K+2))     (mu1 != mu2)
    TH2 = mu*(K+1)/(K+2)                                                  (mu1 == mu2)
Variability enters through the standard two-moment buffer scaling K_eff = K * 2/(c1^2 + c2^2)
(exponential times have c^2 = 1; less variable times behave like a larger buffer), with the
squared CV of a station with r operators taken as c^2/r. The line throughput is the smallest
pair throughput, capped by the bottleneck rate. (Buzacott & Shanthikumar-type two-moment
approximation; no simulation.)"""
import numpy as np


def th_pair(mu1, mu2, K):
    if K > 400:
        return min(mu1, mu2)
    if abs(mu1 - mu2) / max(mu1, mu2) < 1e-9:
        return mu1 * (K + 1) / (K + 2)
    a, c = mu1, mu2
    # numerically stable: divide by max^(K+2)
    m = max(a, c); x, y = a / m, c / m
    return a * c * (x ** (K + 1) - y ** (K + 1)) / (m * (x ** (K + 2) - y ** (K + 2)))


def line_throughput(S, W, r, b):
    S = np.asarray(S, float); W = np.asarray(W, float); r = np.asarray(r, float)
    mu = r / S
    c2 = np.maximum(W / S ** 2, 1e-4) / r
    K = b + 1
    th = mu.min()
    for k in range(len(S) - 1):
        Keff = K * 2.0 / (c2[k] + c2[k + 1])
        th = min(th, th_pair(mu[k], mu[k + 1], Keff))
    return th
