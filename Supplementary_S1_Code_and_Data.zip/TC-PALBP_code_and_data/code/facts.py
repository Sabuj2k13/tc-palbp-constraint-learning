"""Collect every number quoted in the manuscript into manuscript/facts.json."""
import json, glob, os
import numpy as np
import pandas as pd
from instances import vip_instance, generate
from experiments import instance_set

os.makedirs("manuscript", exist_ok=True)
F = {}
S = json.load(open("results/summary.json"))
F.update(S)
acc = json.load(open("runs/surrogate/surrogate_accuracy.json"))
F["sur"] = acc
st = json.load(open("results/structural.json"))
pool = st["E1_pooling"]
F["pool_max_diff_pct"] = round(max(abs(r["TH_r1"] - r["TH_r2"]) for r in pool) * 100, 2)
F["pool_max_gain_pct"] = round(max(r["TH_r2"] - r["TH_r1"] for r in pool) * 100, 2)
F["pool_r2_worse_count"] = int(sum(r["TH_r2"] < r["TH_r1"] for r in pool)); F["pool_n"] = len(pool)
pos = pd.DataFrame(st["E2_position"])
F["pos_max_range_pct"] = round(float((pos.groupby("cv").TH.max() - pos.groupby("cv").TH.min()).max() * 100), 2)
# instances
F["instances"] = [dict(name=i["name"], n=len(i["t"]), work=round(float(i["t"].sum()), 2), os=i.get("os"),
                       long=int((i["t"] > i["takt"]).sum()), arcs=len(i["arcs"])) for i in instance_set()]
# main rows
rows = []
for f in sorted(glob.glob("results/main_results_w*.jsonl")):
    rows += [json.loads(l) for l in open(f)]
df = pd.DataFrame(rows).drop_duplicates(subset=["instance", "scenario", "b", "method"], keep="last")
vip = df[df.instance == "VIP-DFT"]
F["vip"] = {}
for _, r in vip.iterrows():
    F["vip"].setdefault(r.scenario, {})[r.method] = dict(
        ops=None if r.ops != r.ops else int(r.ops), lcb=round(float(r.lcb), 1) if r.lcb == r.lcb else None,
        feasible=bool(r.feasible), stations=r.stations, r=r.r,
        margin=None if r.get("margin") != r.get("margin") else r.get("margin"),
        Ubar=None if r.get("Ubar") != r.get("Ubar") else r.get("Ubar"))
F["secs"] = df.groupby("method").secs.median().round(1).to_dict()
F["gap_pos_share"] = df.groupby("method").mip_gap.apply(lambda s: float((s.fillna(0) > 1e-3).mean())).round(3).to_dict()
# case
case = [json.loads(l) for l in open("results/case_results.jsonl")] if os.path.exists("results/case_results.jsonl") else []
F["case"] = case
# scalability study (40-task instances, 60-s limit)
sc_rows = []
for p in sorted(glob.glob("results/scale_results_w*.jsonl")):
    sc_rows += [json.loads(l) for l in open(p)]
F["scale"] = []
if sc_rows:
    sdf = pd.DataFrame(sc_rows).drop_duplicates(subset=["instance", "scenario", "method"], keep="last")
    for (inst, scn), g in sdf.groupby(["instance", "scenario"]):
        row = dict(instance=inst, scenario=scn, lb=int(g.lb_takt.iloc[0]))
        for _, r in g.iterrows():
            row[r.method] = dict(ops=None if r.ops != r.ops else int(r.ops), feasible=bool(r.feasible),
                                 secs=round(float(r.secs), 0), gap=None if r.get("mip_gap") != r.get("mip_gap") else r.get("mip_gap"))
        F["scale"].append(row)
F["evaluator"] = json.load(open("results/evaluator_comparison.json"))
sens = []
for p in sorted(glob.glob("results/sens_results_w*.jsonl")):
    sens += [json.loads(l) for l in open(p)]
F["sens"] = []
if sens:
    sd = pd.DataFrame(sens).drop_duplicates(subset=["instance", "scenario", "b", "method"], keep="last")
    for (inst, scn, b), g in sd.groupby(["instance", "scenario", "b"]):
        row = dict(instance=inst, scenario=scn, b=int(b), lb=int(g.lb_takt.iloc[0]))
        for _, r in g.iterrows():
            row[r.method] = dict(ops=None if r.ops != r.ops else int(r.ops), feasible=bool(r.feasible))
        F["sens"].append(row)
codes = vip_instance()["codes"]
F["vip_codes"] = codes
import math as _m
def clean(o):
    if isinstance(o, dict): return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [clean(v) for v in o]
    if hasattr(o, "tolist"): return clean(o.tolist())
    if isinstance(o, float) and (_m.isnan(o) or _m.isinf(o)): return None
    return o
json.dump(clean(F), open("manuscript/facts.json", "w"), indent=1, default=str, allow_nan=False)
print("facts ok", len(F))
