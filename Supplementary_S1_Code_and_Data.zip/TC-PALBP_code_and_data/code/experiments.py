"""Computational study. Every case result is appended immediately to
results/main_results.jsonl (one JSON line per method and case), designs included.

Usage: python3 experiments.py <worker_id> <n_workers> [suite]
"""
import sys, json, time, pickle, math, os, glob, zlib
import numpy as np
import models
from models import solve_uniform, solve_chance, solve_tclb, des
from instances import vip_instance, generate
from decomposition import line_throughput

SCENARIOS = {  # human variability scenarios: task-level CV, operator-pace CV
    "S1_task":   dict(cv="const", cv_val=0.15, cvp=0.00),
    "S2_pace":   dict(cv="const", cv_val=0.05, cvp=0.15),
    "S3_mixed":  dict(cv="const", cv_val=0.15, cvp=0.10),
    "S4_hetero": dict(cv="hetero", lo=0.05, hi=0.35, cvp=0.10),
    "S5_high":   dict(cv="const", cv_val=0.30, cvp=0.15),
    "S6_trainee": dict(cv="trainee", base=0.08, high=0.45, share=0.15, cvp=0.05),
}


def instance_set():
    out = [vip_instance()]
    for n in (20, 30):
        for os_ in (0.3, 0.6):
            out.append(generate(n, os_, 2, seed=n * 10 + int(os_ * 10)))
    return out


def cv_vector(inst, sc, seed):
    n = len(inst["t"])
    if sc["cv"] == "const":
        return np.full(n, sc["cv_val"])
    if sc["cv"] == "trainee":   # a few operations staffed by trainees (high variability)
        cv = np.full(n, sc["base"]); k = max(3, int(round(sc["share"] * n)))
        cv[np.random.default_rng(seed).choice(n, k, replace=False)] = sc["high"]
        return cv
    return np.round(np.random.default_rng(seed).uniform(sc["lo"], sc["hi"], n), 3)


def record(f, **kw):
    for k, v in list(kw.items()):
        if isinstance(v, (np.integer,)): kw[k] = int(v)
        if isinstance(v, (np.floating,)): kw[k] = float(v)
    f.write(json.dumps(kw, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o)) + "\n"); f.flush()


def done_set(path):
    s = set()
    if os.path.exists(path):
        for l in open(path):
            d = json.loads(l); s.add((d["instance"], d["scenario"], d["b"], d["method"]))
    return s


def run_case(inst, scn, b, f, tl=30, done=frozenset()):
    sc = SCENARIOS[scn]; cvp = sc["cvp"]
    cv = cv_vector(inst, sc, seed=zlib.crc32(inst["name"].encode()) % 10000)
    sigma2 = (cv * inst["t"]) ** 2
    sur = pickle.load(open(f"runs/surrogate/surrogate_b{b}.pkl", "rb"))
    base = dict(instance=inst["name"], n=len(inst["t"]), scenario=scn, b=b, work=float(inst["t"].sum()),
                lb_takt=math.ceil(inst["t"].sum() / inst["takt"] - 1e-9), cv=cv.tolist(), cvp=cvp)
    key = (inst["name"], scn, b)
    todo = lambda m: key + (m,) not in done
    # 1 deterministic takt design (always solved: reference design for the chance model)
    t0 = time.time(); d0 = solve_uniform(inst, 0.0, tl=tl); g0 = dict(models.LAST); e0 = des(inst, cv, d0, b, cvp=cvp)
    if todo("TAKT"):
        record(f, **base, method="TAKT", ops=sum(d0["r"]), des_mean=e0["mean"], lcb=e0["lcb"], feasible=e0["feasible"],
               secs=time.time() - t0, mip_gap=g0.get("gap"), n_des=1, stations=d0["stations"], r=d0["r"])
    # 2 uniform margin tuned by DES (smallest margin whose design passes)
    if todo("UNIFORM_TUNED"):
        t0 = time.time(); n_des = 0; gaps = []
        for m in np.round(np.arange(0.0, 0.205, 0.01), 2):
            d = d0 if m == 0 else solve_uniform(inst, m, tl=tl)
            if not d["stations"]:
                continue
            gaps.append(models.LAST.get("gap") if m > 0 else g0.get("gap"))
            e = e0 if m == 0 else des(inst, cv, d, b, cvp=cvp); n_des += 1
            if e["feasible"]:
                break
        record(f, **base, method="UNIFORM_TUNED", margin=float(m), ops=sum(d["r"]), des_mean=e["mean"], lcb=e["lcb"],
               feasible=e["feasible"], secs=time.time() - t0, mip_gap=max([g for g in gaps if g is not None], default=None),
               n_des=n_des, stations=d["stations"], r=d["r"])
    # 3 station-level chance constraints
    for al in (0.90, 0.95):
        if not todo(f"CHANCE_{int(al*100)}"):
            continue
        t0 = time.time(); d = solve_chance(inst, sigma2, al, tl=tl, ref=d0, cvp=cvp); g = dict(models.LAST)
        if d["stations"]:
            e = des(inst, cv, d, b, cvp=cvp)
            record(f, **base, method=f"CHANCE_{int(al*100)}", ops=sum(d["r"]), des_mean=e["mean"], lcb=e["lcb"],
                   feasible=e["feasible"], secs=time.time() - t0, mip_gap=g.get("gap"), n_des=1,
                   stations=d["stations"], r=d["r"])
        else:
            record(f, **base, method=f"CHANCE_{int(al*100)}", ops=None, feasible=False, secs=time.time() - t0, status=d["status"])
    # 3b analytical decomposition baseline (no simulation): smallest uniform margin whose design
    #    the pairwise decomposition predicts to meet demand (with the same 0.3% margin as TC-PALBP)
    if todo("UNIFORM_DECOMP"):
        t0 = time.time(); gaps = []
        for m in np.round(np.arange(0.0, 0.205, 0.01), 2):
            d = d0 if m == 0 else solve_uniform(inst, m, tl=tl)
            if not d["stations"]:
                continue
            gaps.append(models.LAST.get("gap") if m > 0 else g0.get("gap"))
            S = np.array([inst["t"][s].sum() for s in d["stations"]]); V = np.array([sigma2[s].sum() for s in d["stations"]])
            W = (1 + cvp ** 2) * V + cvp ** 2 * S ** 2
            th = line_throughput(S, W, d["r"], b)
            if th * inst["takt"] >= 1.003:
                break
        e = des(inst, cv, d, b, cvp=cvp)
        record(f, **base, method="UNIFORM_DECOMP", margin=float(m), predicted_th=float(th * inst["takt"]), ops=sum(d["r"]),
               des_mean=e["mean"], lcb=e["lcb"], feasible=e["feasible"], secs=time.time() - t0,
               mip_gap=max([g for g in gaps if g is not None], default=None), n_des=0, stations=d["stations"], r=d["r"])
    # 4 proposed: V = DES-verified search, C = one-shot with 95% conformal margin
    for mode in ("V", "C"):
        if not todo("TCLB_" + mode):
            continue
        t0 = time.time(); d = solve_tclb(inst, cv, sur, b, tl=tl, cvp=cvp, mode=mode, n_levels=14 if mode == "V" else 6)
        if d["stations"]:
            record(f, **base, method="TCLB_" + mode, source=d.get("source"), ops=sum(d["r"]), des_mean=d["des"]["mean"], lcb=d["des"]["lcb"],
                   feasible=d["des"]["feasible"], secs=time.time() - t0, mip_gap=d["mip"].get("gap"), n_des=d["n_des"],
                   n_solve=d["n_solve"], Ubar=d["Ubar"], H=d["H"], Hmax=d["Hmax"], tried=d["tried"],
                   stations=d["stations"], r=d["r"])
        else:
            record(f, **base, method="TCLB_" + mode, ops=None, feasible=False, secs=time.time() - t0, tried=d["tried"])


if __name__ == "__main__":
    wid, nw = int(sys.argv[1]), int(sys.argv[2])
    suite = sys.argv[3] if len(sys.argv) > 3 else "main"
    os.makedirs("results", exist_ok=True)
    cases = []
    if suite == "main":
        for inst in instance_set():
            for scn in SCENARIOS:
                cases.append((inst, scn, 2))
    elif suite == "scale":      # scalability: 40-task instances, longer solver limit
        for os_ in (0.3, 0.6):
            inst = generate(40, os_, 2, seed=400 + int(os_ * 10))
            for scn in ("S1_task", "S3_mixed", "S6_trainee"):
                cases.append((inst, scn, 2))
    elif suite == "sens":       # sensitivity: buffer size and number of long tasks
        for inst in (generate(20, 0.3, 2, seed=203), generate(30, 0.3, 2, seed=303)):
            for b in (1, 3):
                for scn in ("S3_mixed", "S6_trainee"):
                    cases.append((inst, scn, b))
        for nl in (0, 4):
            inst = generate(30, 0.3, nl, seed=303); inst["name"] = f"G30-OS30-L{nl}"
            for scn in ("S3_mixed", "S6_trainee"):
                cases.append((inst, scn, 2))
    elif suite == "buffers":
        for b in (1, 3, 5):
            for scn in ("S1_task", "S3_mixed"):
                cases.append((vip_instance(), scn, b))
    path = f"results/{suite}_results_w{wid}.jsonl"
    done = set()
    for p in glob.glob(f"results/{suite}_results_w*.jsonl"):
        done |= done_set(p)
    out = open(path, "a")
    for k, (inst, scn, b) in enumerate(cases):
        if k % nw != wid:
            continue
        print(time.strftime("%H:%M:%S"), "case", k, inst["name"], scn, b, flush=True)
        run_case(inst, scn, b, out, done=done, tl=60 if suite == "scale" else 30)
    print("done", flush=True)
