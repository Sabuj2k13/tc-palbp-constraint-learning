"""MILP models (PuLP + HiGHS).

  takt      : SALBP with variable parallel stations, deterministic, cycle = takt
  uniform   : same with a uniform planning margin (cycle = (1-m) takt)
  chance    : station-level chance constraint  S + z_a sqrt(V) <= r T  (normal approx.,
              outer-linearised; the state-of-the-art stochastic SALBP treatment)
  tclb      : proposed throughput-constrained model with the learned convex loss
              (one MILP per bottleneck-utilisation level U_bar), verified by DES with
              no-good cuts until the design meets demand.
"""
import math
import time
import numpy as np
import pulp
from scipy import stats
from sim import evaluate_design, lcb
from instances import transitive_closure


def transitive(inst):
    if '_R' not in inst:
        inst['_R'] = transitive_closure(len(inst['t']), inst['arcs'])
    return inst['_R']


def _base(inst, m, rmax=2, dup_long_only=True, name="m", long_thr=None):
    t = inst["t"]; n = len(t); T = inst["takt"]
    P = pulp.LpProblem(name, pulp.LpMinimize)
    J = range(m); R = range(1, rmax + 1)
    x = pulp.LpVariable.dicts("x", (range(n), J), cat="Binary")
    y = pulp.LpVariable.dicts("y", (J, R), cat="Binary")
    S = pulp.LpVariable.dicts("S", (J, R), lowBound=0)
    for i in range(n):
        P += pulp.lpSum(x[i][j] for j in J) == 1
    for j in J:
        P += pulp.lpSum(y[j][r] for r in R) <= 1
        if j > 0:
            P += pulp.lpSum(y[j][r] for r in R) <= pulp.lpSum(y[j - 1][r] for r in R)
        for i in range(n):
            P += x[i][j] <= pulp.lpSum(y[j][r] for r in R)
        P += pulp.lpSum(S[j][r] for r in R) == pulp.lpSum(float(t[i]) * x[i][j] for i in range(n))
        if dup_long_only:
            thr = T if long_thr is None else long_thr
            long = [i for i in range(n) if t[i] > thr + 1e-9]
            for r in R:
                if r > 1:
                    P += y[j][r] <= pulp.lpSum(x[i][j] for i in long)
    for a, b in inst["arcs"]:
        P += pulp.lpSum(j * x[a][j] for j in J) <= pulp.lpSum(j * x[b][j] for j in J)
    # station windows (classical SALBP preprocessing, here with capacity rmax*T per station):
    # all predecessors of i plus i need >= ceil(head_i/(rmax*T)) stations
    Rc = transitive(inst)
    cap = rmax * T * 1.0001
    for i in range(n):
        head = t[i] + sum(t[k] for k in range(n) if Rc[k, i])
        E = max(0, math.ceil(head / cap) - 1)
        for j in J:
            if j < E:
                P += x[i][j] == 0
    # symmetry/valid inequality: total capacity of opened stations covers work content
    P += pulp.lpSum(S[j][r] for j in J for r in R) == float(t.sum())
    ops = pulp.lpSum(r * y[j][r] for j in J for r in R)
    dup = pulp.lpSum(y[j][r] for j in J for r in R if r > 1)
    return P, x, y, S, ops, dup, J, R


def _extract(inst, x, y, J, R):
    n = len(inst["t"])
    stations, r = [], []
    for j in J:
        rr = [k for k in R if (y[j][k].value() or 0) > 0.5]
        if not rr:
            continue
        tasks = [i for i in range(n) if (x[i][j].value() or 0) > 0.5]
        if tasks:
            stations.append(tasks); r.append(rr[0])
    return stations, r


LAST = {}


def _solve(P, tl, warm=False):
    s = pulp.HiGHS(msg=False, timeLimit=tl, gapRel=1e-4, warmStart=warm)
    t0 = time.time()
    P.solve(s)
    sec = time.time() - t0
    try:
        info = P.solverModel.getInfo()
        LAST.update(gap=float(info.mip_gap), bound=float(info.mip_dual_bound), nodes=int(info.mip_node_count))
    except Exception:
        LAST.update(gap=None, bound=None, nodes=None)
    LAST["timed_out"] = sec >= tl - 0.5
    return pulp.LpStatus[P.status], sec


def m_bound(inst, ufloor=0.85, extra=3):
    """Upper bound on the number of stations: opened stations <= operators, and every
    reported design uses at most ceil(work/(ufloor*T)) + extra operators (checked after each
    solve: if the bound is binding the model is re-solved with a larger bound)."""
    t = inst["t"]
    return int(min(len(t), math.ceil(t.sum() / (ufloor * inst["takt"])) + extra))


def solve_uniform(inst, margin=0.0, tl=120, dup_long_only=True):
    T = inst["takt"]; C = (1 - margin) * T
    P, x, y, S, ops, dup, J, R = _base(inst, m_bound(inst), dup_long_only=dup_long_only, name="uniform", long_thr=C)
    for j in J:
        for r in R:
            P += S[j][r] <= r * C * y[j][r]
    P += ops + 0.01 * dup
    st, sec = _solve(P, tl)
    stn, r = _extract(inst, x, y, J, R)
    return dict(status=st, secs=sec, stations=stn, r=r)


def solve_chance(inst, sigma2, alpha=0.95, tl=120, dup_long_only=True, ref=None, cvp=0.0):
    """Station-level chance constraint P(station time <= r T) >= alpha under the normal
    approximation, S + z_alpha sqrt(V) <= r T (stochastic SALBP; e.g. Chiang et al. 2016).
    sqrt(V) is replaced by its conservative tangent (V + a_r^2)/(2 a_r) >= sqrt(V), with a_r the
    mean station standard deviation (per operator count r) of the deterministic takt design,
    so every returned design satisfies the chance constraint."""
    T = inst["takt"]; z = stats.norm.ppf(alpha); t = inst["t"]; n = len(t)
    if ref is None:
        ref = solve_uniform(inst, 0.0, tl=tl)
    a = {}
    for rr in (1, 2):
        sd = [math.sqrt(sigma2[s].sum()) for s, k in zip(ref["stations"], ref["r"]) if k == rr]
        a[rr] = max(np.mean(sd) if sd else math.sqrt(np.mean(sigma2)), 1e-4)
    thr = min([t[i] for i in range(n) if t[i] * (1 + z * cvp) + z * math.sqrt(sigma2[i]) > T], default=T + 1) - 1e-6
    P, x, y, S, ops, dup, J, R = _base(inst, m_bound(inst), dup_long_only=dup_long_only, name="chance", long_thr=thr)
    V = pulp.LpVariable.dicts("V", (J, R), lowBound=0)
    vmax = float(np.sum(sigma2))
    for j in J:
        P += pulp.lpSum(V[j][r] for r in R) == pulp.lpSum(float(sigma2[i]) * x[i][j] for i in range(n))
        for r in R:
            P += V[j][r] <= vmax * y[j][r]
            # V_total = (1+cvp^2) V_task + cvp^2 S^2 ; sqrt(V_total) <= sqrt((1+cvp^2)V_task) + cvp S
            k1 = math.sqrt(1 + cvp ** 2)
            P += S[j][r] * (1 + z * cvp) + z * k1 * (V[j][r] + a[r] ** 2 * y[j][r]) / (2 * a[r]) <= r * T * y[j][r]
    P += ops + 0.01 * dup
    st, sec = _solve(P, tl)
    stn, r = _extract(inst, x, y, J, R)
    return dict(status=st, secs=sec, stations=stn, r=r, a=a)


def solve_tclb_level(inst, sigma2, sur, Ubar, gamma=0.003, tl=120, cuts=(), dup_long_only=True, cvp=0.0, warm=None, ops_cap=None):
    """Proposed model for one bottleneck-utilisation level Ubar."""
    T = inst["takt"]; c = Ubar * T
    Hmax = -math.log(Ubar) - sur.q - math.log(1 + gamma)
    if Hmax <= 0:
        return None
    P, x, y, S, ops, dup, J, R = _base(inst, m_bound(inst), dup_long_only=dup_long_only, name="tclb", long_thr=c)
    n = len(inst["t"])
    V = pulp.LpVariable.dicts("V", (J, R), lowBound=0)
    vmax = float(np.sum(sigma2))
    terms = sur.terms()
    Hexpr = []
    for j in J:
        P += pulp.lpSum(V[j][r] for r in R) == pulp.lpSum(float(sigma2[i]) * x[i][j] for i in range(n))
        for r in R:
            P += V[j][r] <= vmax * y[j][r]
            P += S[j][r] <= r * c * y[j][r]
            rho = (1.0 / (r * c)) * S[j][r]
            # relative unit-time variance w = (1+cvp^2) V_task/c^2 + cvp^2 r^2 rho^2 ;
            # rho^2 is represented by its tangent lower envelope (qv >= rho^2 at the optimum)
            if cvp > 0:
                qv = pulp.LpVariable(f"q_{j}_{r}", lowBound=0)
                for a0 in np.linspace(0.5, 1.0, 11):
                    P += qv >= 2 * a0 * rho - a0 * a0 * y[j][r]
                w = (1 + cvp ** 2) / c ** 2 * V[j][r] + cvp ** 2 * r * r * qv
            else:
                w = (1.0 / c ** 2) * V[j][r]
            for q, (rr, beta, kappa, theta) in enumerate(terms):
                if rr != r:
                    continue
                if beta == "lin_w":
                    Hexpr.append(theta * w)
                else:
                    zv = pulp.LpVariable(f"z_{j}_{r}_{q}", lowBound=0)
                    P += zv >= rho + beta * w - kappa * y[j][r]
                    Hexpr.append(theta * zv)
    H = pulp.lpSum(Hexpr)
    P += H <= Hmax
    for cut in cuts:   # no-good cuts on (task->station, operators) patterns rejected by DES
        P += pulp.lpSum(x[i][j] for (i, j) in cut["x1"]) + pulp.lpSum(y[j][r] for (j, r) in cut["y1"]) \
            <= len(cut["x1"]) + len(cut["y1"]) - 1
    P += ops + 0.01 * dup + 0.001 * H
    if ops_cap is not None:
        P += ops <= ops_cap
    if warm is not None and warm.get("stations"):
        for j in J:
            for r in R:
                y[j][r].setInitialValue(0)
            for i in range(n):
                x[i][j].setInitialValue(0)
        for j, (tasks, rr) in enumerate(zip(warm["stations"], warm["r"])):
            if j >= len(J):
                break
            y[j][rr].setInitialValue(1)
            for i in tasks:
                x[i][j].setInitialValue(1)
    st, sec = _solve(P, tl, warm=warm is not None)
    if st != "Optimal" and not (st == "Not Solved" and x[0][0].value() is not None):
        return dict(status=st, secs=sec, stations=None, r=None, Ubar=Ubar)
    stn, r = _extract(inst, x, y, J, R)
    x1 = [(i, j) for i in range(n) for j in J if (x[i][j].value() or 0) > 0.5]
    y1 = [(j, k) for j in J for k in R if (y[j][k].value() or 0) > 0.5]
    return dict(status=st, secs=sec, stations=stn, r=r, Ubar=Ubar, H=float(pulp.value(H)), Hmax=Hmax,
                cut=dict(x1=x1, y1=y1))


def des(inst, cv, design, b, reps=30, seed0=1000, cvp=0.0):
    x = evaluate_design(inst["t"], cv, design["stations"], design["r"], b=b, reps=reps, seed0=seed0, cvp=cvp)
    target = 480.0 / inst["takt"]
    return dict(mean=float(x.mean()), lcb=lcb(x), feasible=bool(lcb(x) >= target), target=target)


def solve_tclb(inst, cv, sur, b, max_cuts=3, tl=30, dup_long_only=True, log=None, cvp=0.0, step=0.01, n_levels=10, mode="V"):
    """Search over bottleneck-utilisation levels U_bar, descending from the largest level allowed
    by the margin.
    mode "V": at each level the uniform-margin design (m = 1 - U_bar) is verified by DES and, if it
      meets demand, becomes the incumbent; the TC-PALBP MILP then searches for a design with fewer
      operators (ops <= incumbent - 1) that satisfies the learned constraint (median margin).
      Candidates are verified by DES (30 replications, LCB >= demand); rejected designs are excluded
      by no-good cuts (at most max_cuts per level). Never worse than the best uniform design on the grid.
    mode "C": one-shot; 95% split-conformal margin; DES only to report the result.
    The search stops when no lower level can need fewer operators than the incumbent."""
    sigma2 = (np.asarray(cv) * inst["t"]) ** 2
    T = inst["takt"]; work = float(inst["t"].sum())
    sur.q = sur.q95 if mode == "C" else sur.qs[0.5]
    top = math.floor(math.exp(-sur.q) / 1.003 / step) * step
    levels = [round(top - k * step, 4) for k in range(n_levels)]
    t0 = time.time(); tried = []; best = None; n_solve = 0
    for Ub in levels:
        lb = math.ceil(work / (Ub * T) - 1e-9)
        if best is not None and lb >= sum(best["r"]):
            break
        w0 = solve_uniform(inst, 1 - Ub, tl=tl, dup_long_only=dup_long_only); n_solve += 1
        g0 = dict(LAST)
        if mode == "V" and w0["stations"]:
            e0 = des(inst, cv, w0, b, cvp=cvp)
            tried.append(dict(Ubar=float(Ub), ops=int(sum(w0["r"])), source="uniform", lcb=e0["lcb"], feasible=e0["feasible"]))
            if e0["feasible"] and (best is None or sum(w0["r"]) < sum(best["r"])):
                best = dict(w0, des=e0, Ubar=Ub, source="uniform", H=None, Hmax=None, mip=g0)
        cap = None if best is None else sum(best["r"]) - 1
        if cap is not None and cap < lb:
            continue
        cuts = []
        for it in range(max_cuts + 1):
            d = solve_tclb_level(inst, sigma2, sur, Ub, tl=tl, cuts=cuts, dup_long_only=dup_long_only, cvp=cvp,
                                 warm=w0 if (it == 0 and cap is None) else None, ops_cap=cap)
            n_solve += 1
            if not d or not d["stations"]:
                break
            if best is not None and sum(d["r"]) >= sum(best["r"]):
                break
            d["mip"] = dict(LAST); d["source"] = "learned"
            e = des(inst, cv, d, b, cvp=cvp)
            tried.append(dict(Ubar=float(Ub), ops=int(sum(d["r"])), source="learned", H=d["H"], Hmax=d["Hmax"], lcb=e["lcb"], feasible=e["feasible"]))
            if log:
                log(f"   Ubar={Ub:.2f} ops={sum(d['r'])} H={d['H']:.4f}/{d['Hmax']:.4f} DES lcb={e['lcb']:.1f} ok={e['feasible']}")
            if mode == "C" or e["feasible"]:
                d["des"] = e; best = d
                break
            cuts.append(d["cut"])
        if mode == "C" and best is not None:
            pass
    if best is None:
        return dict(stations=None, r=None, secs_total=time.time() - t0, tried=tried, n_solve=n_solve)
    best.update(secs_total=time.time() - t0, tried=tried, n_solve=n_solve, n_des=len(tried))
    return best
