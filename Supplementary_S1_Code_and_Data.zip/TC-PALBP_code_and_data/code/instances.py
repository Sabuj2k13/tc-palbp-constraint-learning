"""VIP Industries DFT-bag sewing line (Table 2 of the manuscript) and a generator of
benchmark instances with long tasks, built the way SALBPGen (Otto et al. 2013) controls
order strength and task-time distribution."""
import numpy as np

VIP_CODES = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ") + ["@"]
VIP_T = [0.25, 0.70, 0.75, 0.33, 0.20, 0.19, 0.47, 0.75, 0.80, 0.32, 0.19, 0.42, 0.62, 0.62,
         0.42, 0.13, 0.97, 0.30, 0.42, 1.20, 0.33, 1.25, 0.67, 0.42, 0.75, 0.33, 1.00]
VIP_PRED = {"A": [], "B": ["A"], "C": [], "D": ["B"], "E": ["C"], "F": [], "G": ["F"],
            "H": ["E", "G"], "I": ["D"], "J": ["K"], "K": ["H"], "L": ["M"], "M": [],
            "N": ["I", "L"], "O": ["N"], "P": ["J"], "Q": ["O"], "R": [], "S": [], "T": ["R"],
            "U": ["S"], "V": ["T"], "W": ["P", "U"], "X": ["V", "W"], "Y": ["Z"], "Z": ["Q", "X"],
            "@": ["Y"]}


def vip_instance():
    idx = {c: i for i, c in enumerate(VIP_CODES)}
    arcs = [(idx[p], idx[c]) for c, ps in VIP_PRED.items() for p in ps]
    return dict(name="VIP-DFT", t=np.array(VIP_T), arcs=arcs, codes=VIP_CODES, takt=1.0)


def transitive_closure(n, arcs):
    R = np.zeros((n, n), bool)
    for a, b in arcs:
        R[a, b] = True
    for k in range(n):
        R |= R[:, [k]] & R[[k], :]
    return R


def order_strength(n, arcs):
    return transitive_closure(n, arcs).sum() / (n * (n - 1) / 2)


def generate(n, os_target, n_long, seed, takt=1.0, mean_t=0.55):
    """Random precedence graph with order strength ~ os_target; task times lognormal
    (mean mean_t*takt, CV 0.5), truncated to [0.1, 0.95]*takt, plus n_long tasks in
    (1.05, 1.45]*takt that force paralleling."""
    rng = np.random.default_rng(seed)
    # topological order = index order; add random arcs until OS reached
    arcs = set()
    # guarantee a connected-ish structure: each task (except roots) gets one predecessor
    for j in range(1, n):
        if rng.random() < 0.85:
            arcs.add((int(rng.integers(max(0, j - 6), j)), j))
    while order_strength(n, arcs) < os_target:
        a = int(rng.integers(0, n - 1))
        b = int(rng.integers(a + 1, min(n, a + 8)))
        arcs.add((a, b))
    # remove transitive (redundant) arcs for a clean graph
    R = transitive_closure(n, arcs)
    clean = [(a, b) for (a, b) in arcs if not any(R[a, c] and R[c, b] for c in range(a + 1, b))]
    s2 = np.log(1 + 0.5 ** 2)
    t = np.exp(np.log(mean_t * takt) - s2 / 2 + np.sqrt(s2) * rng.standard_normal(n))
    t = np.clip(t, 0.1 * takt, 0.95 * takt)
    long_idx = rng.choice(n, n_long, replace=False)
    t[long_idx] = rng.uniform(1.05, 1.45, n_long) * takt
    t = np.round(t, 2)
    return dict(name=f"G{n}-OS{int(os_target*100)}-s{seed}", t=t, arcs=sorted(clean),
                codes=[f"T{i+1}" for i in range(n)], takt=takt,
                os=round(float(order_strength(n, clean)), 3))
