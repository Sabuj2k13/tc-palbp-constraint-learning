"""Figure: learned station loss h_r(rho, w) for single vs duplicated stations, and surrogate
accuracy (predicted vs simulated throughput on held-out lines)."""
import pickle, json, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
PAL = ["#2a78d6", "#eb6834", "#1baf7a"]; INK2, GRID = "#52514e", "#e4e3df"
s = pickle.load(open("runs/surrogate/surrogate_b2.pkl", "rb"))
D = np.load("runs/surrogate/training_data_b2.npz"); te = D["split_test"]
fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.0))
rho = np.linspace(0.8, 1.0, 81)
for k, cv in enumerate((0.1, 0.2, 0.3)):
    axs[0].plot(rho, [s.h(r, (cv * r) ** 2, 1) * 100 for r in rho], color=PAL[k], lw=2, label=f"single, CV {cv}")
    axs[0].plot(rho, [s.h(r, (cv * 2 * r) ** 2, 2) * 100 for r in rho], color=PAL[k], lw=2, ls="--", label=f"duplicated, CV {cv}")
axs[0].set_xlabel("Relative station load ρ = (S/r)/c"); axs[0].set_ylabel("Learned throughput loss h (%)")
axs[0].legend(fontsize=6.5, frameon=False); axs[0].grid(color=GRID); axs[0].spines[["top", "right"]].set_visible(False)
y = D["y"][te]; p = D["X"][te] @ s.theta
axs[1].scatter(np.exp(-y) * 100, np.exp(-p) * 100, s=5, color=PAL[0], alpha=0.5, edgecolor="none")
lo = min(np.exp(-y).min(), np.exp(-p).min()) * 100
axs[1].plot([lo, 100], [lo, 100], color=INK2, lw=1, ls="--")
axs[1].set_xlabel("Simulated throughput / capacity (%)"); axs[1].set_ylabel("Predicted (%)")
axs[1].grid(color=GRID); axs[1].spines[["top", "right"]].set_visible(False)
axs[1].set_title("Held-out lines, buffer 2", fontsize=8, color=INK2)
fig.tight_layout(); fig.savefig("results/fig_surrogate.png", dpi=300)
print("ok")
