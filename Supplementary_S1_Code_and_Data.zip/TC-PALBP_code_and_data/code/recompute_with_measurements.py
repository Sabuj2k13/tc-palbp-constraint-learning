"""Re-run the VIP analysis with measured time-study data (see 07_Field_Data_Protocol).
Usage: python3 recompute_with_measurements.py time_study.csv [buffer_size]"""
import sys, json, pickle, csv, math
import numpy as np
import pandas as pd
from instances import vip_instance
from models import solve_uniform, solve_chance, solve_tclb, des


def estimate(df):
    rows = []
    for op, g in df.groupby("operation_code"):
        piv = g.pivot_table(index=["operator_id", "date", "cycle_no"], columns="element_no",
                            values="element_time_s", aggfunc="sum").dropna()
        X = piv.sum(axis=1).values / 60.0                     # minutes per cycle
        t = X.mean(); var = X.var(ddof=1)
        C = np.cov(piv.values.T / 60.0, ddof=1) if piv.shape[1] > 1 else np.zeros((1, 1))
        off = C.sum() - np.trace(C)
        cvp2 = max(off, 0.0) / t ** 2
        cv2 = max(var / t ** 2 - cvp2, 0.0)
        rows.append(dict(op=op, n_cycles=len(X), t=t, cv_total=math.sqrt(var) / t,
                         cv_pace=math.sqrt(cvp2), cv_task=math.sqrt(cv2)))
    return pd.DataFrame(rows)


if __name__ == "__main__":
    df = pd.read_csv(sys.argv[1]); b = int(sys.argv[2]) if len(sys.argv) > 2 else 2
    est = estimate(df)
    inst = vip_instance(); codes = inst["codes"]
    missing = [c for c in codes if c not in set(est.op)]
    if missing:
        print("WARNING: no data for", missing, "- SMV and median CVs used for them")
    e = est.set_index("op")
    t = np.array([e.t.get(c, inst["t"][i]) for i, c in enumerate(codes)])
    cv = np.array([e.cv_task.get(c, e.cv_task.median()) for c in codes])
    cvp = float(e.cv_pace.median())
    inst["t"] = t
    print(est.round(3).to_string()); print("line pace CV =", round(cvp, 3))
    sur = pickle.load(open(f"../03_Simulation_Runs/surrogate/surrogate_b{b}.pkl", "rb"))
    out = {}
    d0 = solve_uniform(inst, 0.0, tl=60); out["TAKT"] = (d0, des(inst, cv, d0, b, cvp=cvp))
    for m in np.arange(0.01, 0.2, 0.01):
        d = solve_uniform(inst, m, tl=60); ev = des(inst, cv, d, b, cvp=cvp)
        if ev["feasible"]:
            out["UNIFORM_TUNED"] = (d, ev); break
    d = solve_chance(inst, (cv * t) ** 2, 0.95, tl=60, ref=d0, cvp=cvp); out["CHANCE_95"] = (d, des(inst, cv, d, b, cvp=cvp))
    for mode in ("V", "C"):
        d = solve_tclb(inst, cv, sur, b, tl=60, cvp=cvp, mode=mode); out["TCLB_" + mode] = (d, d.get("des"))
    res = {k: dict(ops=int(sum(v[0]["r"])), stations=[[codes[i] for i in s] for s in v[0]["stations"]],
                   operators=v[0]["r"], des=v[1]) for k, v in out.items() if v[0].get("stations")}
    json.dump(dict(estimates=est.to_dict("records"), cv_pace=cvp, results=res),
              open("../04_Results/vip_measured_results.json", "w"), indent=1, default=float)
    est.to_csv("../04_Results/vip_measured_variability.csv", index=False)
    for k, v in res.items():
        print(k, v["ops"], v["des"])
