"""Learned convex throughput-loss constraint (optimisation with constraint learning,
Fajemisin, Maragno and den Hertog 2024, EJOR 314(1):1-14).

For a serial line with station work contents S_k, operators r_k, unit-time variances V_k,
bottleneck cycle c = max_k S_k / r_k, the throughput loss relative to bottleneck capacity is

    H = log( (1/c) / TH )  >= 0.

H is modelled as an additive sum of convex station terms of bottleneck-relative features
    rho_k = (S_k/r_k)/c  (relative load),   w_k = V_k / c^2  (relative variance),
    H_hat = sum_k h_{r_k}(rho_k, w_k),
    h_r(rho,w) = sum_m theta_{r,m} max(0, rho + beta_m w - kappa_m) + theta_{r,0} w,  theta >= 0
(non-negative least squares).  Each h_r is convex and non-decreasing, hence exactly
representable by linear epigraph constraints in the MILP (models.py), where c is fixed to
U_bar * T on a grid of bottleneck-utilisation levels U_bar.  A split-conformal quantile q of
the residuals is the calibrated safety margin.
"""
import numpy as np
from scipy.optimize import nnls
from sim import evaluate_station_line

BETAS = [0.0, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0]
KAPPAS = list(np.round(np.arange(0.70, 1.0001, 0.02), 3))
R_LEVELS = (1, 2)
BASIS = [(b, k) for b in BETAS for k in KAPPAS] + [("lin_w", None)]
NB = len(BASIS)


def station_features(rho, w):
    return np.array([w if b == "lin_w" else max(0.0, rho + b * w - k) for (b, k) in BASIS])


def line_features(S, V, r):
    S = np.asarray(S, float); V = np.asarray(V, float); r = np.asarray(r, int)
    c = np.max(S / r)
    X = np.zeros(len(R_LEVELS) * NB)
    for Sk, Vk, rk in zip(S, V, r):
        g = R_LEVELS.index(int(rk))
        X[g * NB:(g + 1) * NB] += station_features(Sk / rk / c, Vk / c ** 2)
    return X


def random_line(rng):
    """Training-design distribution: 5-25 stations, 10-40% duplicated, loads skewed towards
    the bottleneck (as in balanced lines), station CVs 0-0.40."""
    K = int(rng.integers(5, 26))
    p2 = rng.choice([0.1, 0.25, 0.4])
    r = np.where(rng.random(K) < p2, 2, 1)
    rho = 1 - rng.beta(0.7, 3.0, K) * 0.5
    rho[rng.integers(K)] = 1.0
    cv = rng.uniform(0.0, 0.40, K) * (rng.random(K) < 0.95)
    S = rho * r
    V = (cv * S) ** 2
    return S, V, r, cv


def make_dataset(n_lines, b, seed, reps=10):
    rng = np.random.default_rng(seed)
    X, y, raw = [], [], []
    for i in range(n_lines):
        S, V, r, cv = random_line(rng)
        th = evaluate_station_line(S, cv, r, b=b, reps=reps, seed0=seed * 1000003 + i * reps).mean() / 480.0
        c = np.max(S / r)
        X.append(line_features(S, V, r))
        y.append(np.log(1.0 / (c * th)))
        raw.append((len(S), int((r == 2).sum()), float(np.mean(cv)), th, c))
    return np.array(X), np.array(y), np.array(raw)


class Surrogate:
    def __init__(self, b):
        self.b = b

    def fit(self, X, y):
        self.theta, _ = nnls(X, y, maxiter=50000)
        return self

    def predict(self, X):
        return X @ self.theta

    def calibrate(self, X, y, alpha=0.05):
        res = np.sort(y - self.predict(X))
        k = int(np.ceil((len(res) + 1) * (1 - alpha)))
        self.q = float(res[min(k, len(res)) - 1])
        return self.q

    def terms(self, tol=1e-7):
        out = []
        for g, rr in enumerate(R_LEVELS):
            for m, (bb, kk) in enumerate(BASIS):
                th = self.theta[g * NB + m]
                if th > tol:
                    out.append((rr, bb, kk, float(th)))
        return out

    def h(self, rho, w, r):
        g = R_LEVELS.index(int(r))
        return float(station_features(rho, w) @ self.theta[g * NB:(g + 1) * NB])

    def predict_line(self, S, V, r):
        return float(line_features(S, V, r) @ self.theta)
