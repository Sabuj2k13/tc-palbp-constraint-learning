"""Train and calibrate the convex surrogate for buffer sizes 1,2,3,5; benchmark against an
unconstrained gradient-boosting model on the same data. Outputs -> runs/surrogate/"""
import numpy as np, pickle, time, json
from sklearn.ensemble import HistGradientBoostingRegressor
from surrogate import make_dataset, Surrogate
res = {}
for b in [1, 2, 3, 5]:
    t0 = time.time()
    X, y, raw = make_dataset(8000, b, seed=b)
    idx = np.random.default_rng(0).permutation(len(y)); tr, ca, te = idx[:5000], idx[5000:6500], idx[6500:]
    s = Surrogate(b).fit(X[tr], y[tr]); q = s.calibrate(X[ca], y[ca])
    p = s.predict(X[te])
    g = HistGradientBoostingRegressor(max_iter=800, learning_rate=0.05).fit(X[tr], y[tr]); pg = g.predict(X[te])
    th_t = np.exp(-y[te]) ; th_p = np.exp(-p); th_g = np.exp(-pg)
    R2 = lambda a, f: 1 - np.sum((a - f) ** 2) / np.sum((a - a.mean()) ** 2)
    res[b] = dict(n_train=len(tr), n_cal=len(ca), n_test=len(te),
                  convex_R2=round(R2(y[te], p), 4), convex_MAPE_TH_pct=round(float(np.mean(abs(th_p - th_t) / th_t) * 100), 3),
                  convex_P95_APE_pct=round(float(np.percentile(abs(th_p - th_t) / th_t * 100, 95)), 3),
                  gbm_R2=round(R2(y[te], pg), 4), gbm_MAPE_TH_pct=round(float(np.mean(abs(th_g - th_t) / th_t) * 100), 3),
                  conformal_q=round(q, 4), test_coverage=round(float(np.mean(y[te] - p <= q)), 3),
                  active_terms=len(s.terms()), seconds=round(time.time() - t0, 1))
    print(b, res[b], flush=True)
    pickle.dump(s, open(f"runs/surrogate/surrogate_b{b}.pkl", "wb"))
    np.savez_compressed(f"runs/surrogate/training_data_b{b}.npz", X=X, y=y, raw=raw, split_train=tr, split_cal=ca, split_test=te)
json.dump(res, open("runs/surrogate/surrogate_accuracy.json", "w"), indent=1)
