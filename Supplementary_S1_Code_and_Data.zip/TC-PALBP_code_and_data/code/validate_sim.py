import numpy as np, time
from sim import _line_departures, _count, _lognormal_station_times, evaluate_design
from simpy_ref import simpy_throughput
from instances import vip_instance
inst = vip_instance(); C = {c:i for i,c in enumerate(inst['codes'])}
A2 = [("CF",1),("GS",1),("EH",1),("KJPR",1),("AB",1),("MU",1),("TW",2),("VX",2),("DL",1),("I",1),("N",1),("OQZ",2),("Y@",2)]
st = [[C[c] for c in s] for s,_ in A2]; r = np.array([x for _,x in A2])
S = np.array([inst['t'][s].sum() for s in st])
print("A2 station loads", S.round(2), "ops", r.sum())
# 1) recursion vs SimPy on identical draws (station-level CV, as in the original paper)
res=[]
for cv in [0.0,0.15,0.30]:
  for b in [1,2]:
    a=[];bb=[]
    for q in range(10):
        P=_lognormal_station_times(q, 700, S, np.full(len(S),cv))
        a.append(_count(_line_departures(P,r,b),60.,540.)); bb.append(simpy_throughput(P,r,b))
    res.append((cv,b,np.mean(a),np.mean(bb)))
    print(f"cv={cv} b={b} recursion={np.mean(a):.1f} simpy={np.mean(bb):.1f} diff%={100*(np.mean(a)-np.mean(bb))/np.mean(bb):.2f}")
# 2) current line deterministic = 384
cur_st=[[i] for i in range(27)]; rr=np.ones(27,int)
x=evaluate_design(inst['t'],np.zeros(27),cur_st,rr,b=2,reps=2); print("current deterministic",x)
t0=time.time(); y=evaluate_design(inst['t'],np.full(27,0.15),st,r,b=2,reps=30); print("A2 task-level cv.15", y.mean(), "time", time.time()-t0)
