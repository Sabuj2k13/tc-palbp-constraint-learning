"""Fast discrete-event evaluation of unpaced serial lines with parallel (duplicated)
stations, finite inter-station buffers and blocking after service.

Line logic (identical to the SimPy reference model in simpy_ref.py;
validated in validate_sim.py):
  * station k has r_k identical operators (r_k in {1,2,3}) sharing one input buffer;
  * the buffer between k and k+1 holds b units (in addition to the r_{k+1} units in process);
  * the first station never starves, the last is never blocked;
  * an operator who finishes a unit while the downstream buffer is full keeps it (BAS).

Recursion: see _line_departures (rank-based, exact, allows overtaking in duplicated stations).
"""
import numpy as np
from numba import njit


@njit(cache=True)
def _line_departures(P, r, b):
    """Exact rank-based recursion with overtaking inside multi-operator stations.
    Quantities are indexed by rank (j-th unit to arrive / start / leave a station).
      start rank m at k : St = max(D[m,k-1], D[m-r_k,k])          (FIFO buffer, r_k operators)
      j-th departure    : D[j,k] = max(min pending finish, D[j-1,k], D[j-b-r_{k+1},k+1])
    Blocked units leave in order of finishing (BAS). Stations are processed on a wavefront
    (station k at rank t-k*L) so every quantity is available when needed."""
    N, K = P.shape
    L = 0
    for k in range(K):
        if r[k] - 1 > L:
            L = r[k] - 1
    D = np.zeros((N, K))
    F = np.zeros((N, K))
    gone = np.zeros((N, K), np.bool_)
    started = np.zeros(K, np.int64)
    lo = np.zeros(K, np.int64)
    for t in range(N + (K - 1) * L):
        for k in range(K):
            j = t - k * L
            if j < 0 or j >= N:
                continue
            hi = j + r[k] - 1
            if hi > N - 1:
                hi = N - 1
            while started[k] <= hi:
                m = started[k]
                a = D[m, k - 1] if k > 0 else 0.0
                free = D[m - r[k], k] if m - r[k] >= 0 else 0.0
                s = a if a > free else free
                F[m, k] = s + P[m, k]
                started[k] += 1
            # earliest-finished unit still in the station
            best = -1
            for m in range(lo[k], started[k]):
                if not gone[m, k] and (best < 0 or F[m, k] < F[best, k]):
                    best = m
            gone[best, k] = True
            while lo[k] < N and gone[lo[k], k]:
                lo[k] += 1
            d = F[best, k]
            if j > 0 and D[j - 1, k] > d:
                d = D[j - 1, k]
            if k < K - 1:
                cap = b + r[k + 1]
                if j - cap >= 0 and D[j - cap, k + 1] > d:
                    d = D[j - cap, k + 1]
            D[j, k] = d
    return D[:, K - 1]


@njit(cache=True)
def _count(dep, t0, t1):
    c = 0
    for x in dep:
        if x > t0 and x <= t1:
            c += 1
    return c


@njit(cache=True)
def _lognormal_station_times(rng_seed, N, means, cvs):
    np.random.seed(rng_seed)
    K = means.shape[0]
    P = np.empty((N, K))
    for k in range(K):
        if cvs[k] <= 0:
            for n in range(N):
                P[n, k] = means[k]
        else:
            s2 = np.log(1.0 + cvs[k] ** 2)
            mu = np.log(means[k]) - 0.5 * s2
            s = np.sqrt(s2)
            for n in range(N):
                P[n, k] = np.exp(mu + s * np.random.randn())
    return P


@njit(cache=True)
def _task_times(rng_seed, N, t, cv):
    """Unit-by-task processing times; task i of unit n ~ lognormal(mean t_i, CV cv_i).
    Same seed -> same draws for every design (common random numbers)."""
    np.random.seed(rng_seed)
    n_t = t.shape[0]
    X = np.empty((N, n_t))
    for i in range(n_t):
        if cv[i] <= 0:
            for n in range(N):
                X[n, i] = t[i]
        else:
            s2 = np.log(1.0 + cv[i] ** 2)
            mu = np.log(t[i]) - 0.5 * s2
            s = np.sqrt(s2)
            for n in range(N):
                X[n, i] = np.exp(mu + s * np.random.randn())
    return X


@njit(cache=True)
def _eval_design(t, cv, station_of, r, b, reps, warm, horizon, N, seed0, cvp):
    K = r.shape[0]
    out = np.empty(reps)
    for q in range(reps):
        X = _task_times(seed0 + q, N, t, cv)
        P = np.zeros((N, K))
        for i in range(t.shape[0]):
            k = station_of[i]
            for n in range(N):
                P[n, k] += X[n, i]
        if cvp > 0:   # operator pace factor, shared by all tasks of one cycle (human variability)
            np.random.seed(seed0 + q + 7777777)
            s2 = np.log(1.0 + cvp ** 2); mu = -0.5 * s2; sd = np.sqrt(s2)
            for k in range(K):
                for n in range(N):
                    P[n, k] *= np.exp(mu + sd * np.random.randn())
        dep = _line_departures(P, r, b)
        out[q] = _count(dep, warm, warm + horizon)
    return out


def units_needed(r, S, warm, horizon):
    """Units to simulate so the last departure surely passes warm+horizon."""
    rate = np.min(r / np.maximum(S, 1e-9))
    return int((warm + horizon) * rate * 1.25) + 50


def evaluate_design(t, cv, stations, r, b=2, reps=30, warm=60.0, horizon=480.0, seed0=1000, cvp=0.0):
    """t, cv: task means and CVs (independent task-level variability); cvp: CV of the operator
    pace factor applied to the whole station time of a cycle (shared variability);
    stations: list of task-index lists in line order; r: operators per station.
    Returns array of units produced per shift (one per replication)."""
    t = np.asarray(t, float)
    cv = np.asarray(cv, float)
    station_of = np.empty(len(t), np.int64)
    for k, tasks in enumerate(stations):
        for i in tasks:
            station_of[i] = k
    r = np.asarray(r, np.int64)
    S = np.array([t[list(s)].sum() for s in stations])
    N = units_needed(r, S, warm, horizon)
    return _eval_design(t, cv, station_of, r, int(b), int(reps), float(warm), float(horizon), N, int(seed0), float(cvp))


def evaluate_station_line(means, cvs, r, b=2, reps=10, warm=60.0, horizon=480.0, seed0=0):
    """Station-level lognormal times (used to generate surrogate training data)."""
    means = np.asarray(means, float)
    cvs = np.asarray(cvs, float)
    r = np.asarray(r, np.int64)
    N = units_needed(r, means, warm, horizon)
    out = np.empty(reps)
    for q in range(reps):
        P = _lognormal_station_times(seed0 + q, N, means, cvs)
        dep = _line_departures(P, r, int(b))
        out[q] = _count(dep, warm, warm + horizon)
    return out


def lcb(x, conf=0.95):
    from scipy import stats
    n = len(x)
    if np.std(x) == 0:
        return float(np.mean(x))
    return float(np.mean(x) - stats.t.ppf(conf, n - 1) * np.std(x, ddof=1) / np.sqrt(n))
