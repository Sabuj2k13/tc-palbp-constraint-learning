"""Aggregate results, statistical tests and figures for the manuscript.
Outputs: results/summary.json, results/table_main_by_method.csv, results/table_by_scenario.csv,
results/table_cases.csv, results/fig_*.png"""
import json, glob, math
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PAL = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#8a6d3b", "#e87ba4", "#6250d6"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
METHODS = ["TAKT", "UNIFORM_TUNED", "CHANCE_90", "CHANCE_95", "UNIFORM_DECOMP", "TCLB_C", "TCLB_V"]
LABEL = {"TAKT": "Takt (deterministic)", "UNIFORM_TUNED": "Uniform margin (DES-tuned)",
         "CHANCE_90": "Station chance, α=0.90", "CHANCE_95": "Station chance, α=0.95", "UNIFORM_DECOMP": "Uniform margin, decomposition",
         "TCLB_C": "TC-PALBP-C (conformal)", "TCLB_V": "TC-PALBP-V (verified)"}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": INK2,
                     "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2})


def load():
    rows = []
    for f in sorted(glob.glob("results/main_results_w*.jsonl")):
        for l in open(f):
            rows.append(json.loads(l))
    df = pd.DataFrame(rows)
    df = df[df.method.isin(METHODS)]
    df = df.drop_duplicates(subset=["instance", "scenario", "b", "method"], keep="last")
    df["excess"] = df["ops"] - df["lb_takt"]
    df["lcb_ratio"] = df["lcb"] / 480.0
    return df


def main():
    df = load()
    complete = df.groupby(["instance", "scenario"]).method.nunique()
    keep = complete[complete == len(METHODS)].index
    d = df.set_index(["instance", "scenario"]).loc[keep].reset_index()
    n_cases = len(keep)
    g = d.groupby("method")
    tab = pd.DataFrame({
        "cases": g.size(),
        "demand_met_pct": g.feasible.mean() * 100,
        "mean_operators": g.ops.mean(),
        "mean_excess_over_LB": g.excess.mean(),
        "mean_LCB_over_target": g.lcb_ratio.mean(),
        "median_secs": g.secs.median(),
        "mean_DES_runs": g.n_des.mean(),
    }).reindex(METHODS)
    tab.round(3).to_csv("results/table_main_by_method.csv")
    by_sc = d.pivot_table(index="scenario", columns="method", values="ops", aggfunc="mean").reindex(columns=METHODS)
    by_sc.round(2).to_csv("results/table_by_scenario.csv")
    feas_sc = d.pivot_table(index="scenario", columns="method", values="feasible", aggfunc="mean").reindex(columns=METHODS)
    cases = d.pivot_table(index=["instance", "scenario"], columns="method", values="ops").reindex(columns=METHODS)
    cases.to_csv("results/table_cases.csv")
    # paired comparisons (operators) of TCLB_V against each feasible-by-construction baseline
    S = {}
    piv = d.pivot_table(index=["instance", "scenario"], columns="method", values="ops")
    fe = d.pivot_table(index=["instance", "scenario"], columns="method", values="feasible")
    for other in ["UNIFORM_TUNED", "CHANCE_90", "CHANCE_95", "TCLB_C"]:
        diff = (piv["TCLB_V"] - piv[other]).dropna()
        w = dict(n=int(len(diff)), fewer=int((diff < 0).sum()), equal=int((diff == 0).sum()), more=int((diff > 0).sum()),
                 mean_diff=float(diff.mean()), total_diff=float(diff.sum()))
        nz = diff[diff != 0]
        w["wilcoxon_p"] = float(stats.wilcoxon(nz).pvalue) if len(nz) >= 5 else None
        S[f"TCLB_V_vs_{other}"] = w
    for other in ["CHANCE_90", "CHANCE_95", "UNIFORM_TUNED", "UNIFORM_DECOMP"]:
        diff = (piv["TCLB_C"] - piv[other]).dropna()
        nz = diff[diff != 0]
        S[f"TCLB_C_vs_{other}"] = dict(n=int(len(diff)), fewer=int((diff < 0).sum()), equal=int((diff == 0).sum()),
            more=int((diff > 0).sum()), mean_diff=float(diff.mean()),
            wilcoxon_p=float(stats.wilcoxon(nz).pvalue) if len(nz) >= 5 else None)
    # reliability at equal operators: TCLB_V vs UNIFORM_TUNED where ops equal
    lc = d.pivot_table(index=["instance", "scenario"], columns="method", values="lcb_ratio")
    eq = piv["TCLB_V"] == piv["UNIFORM_TUNED"]
    S["equal_ops_lcb"] = dict(n=int(eq.sum()), tclb_mean=float(lc.loc[eq, "TCLB_V"].mean()),
                             uni_mean=float(lc.loc[eq, "UNIFORM_TUNED"].mean()),
                             tclb_higher=int((lc.loc[eq, "TCLB_V"] > lc.loc[eq, "UNIFORM_TUNED"]).sum()))
    S["table_main"] = json.loads(tab.round(4).to_json(orient="index"))
    S["by_scenario_ops"] = json.loads(by_sc.round(3).to_json(orient="index"))
    S["by_scenario_feasible"] = json.loads(feas_sc.round(3).to_json(orient="index"))
    S["n_cases"] = n_cases
    dd = d[d.method == "UNIFORM_DECOMP"]
    S["decomp_feasible_rate"] = float(dd.feasible.mean())
    S["decomp_infeasible_cases"] = int((~dd.feasible.astype(bool)).sum())
    S["n_instances"] = int(d.instance.nunique()); S["n_scenarios"] = int(d.scenario.nunique())
    # where did TC-PALBP-V's design come from, and where could anything beat the uniform margin?
    tv = d[d.method == "TCLB_V"].set_index(["instance", "scenario"])
    better = (piv["TCLB_V"] < piv["UNIFORM_TUNED"])
    S["tclbV_better_cases"] = [list(k) for k in better[better].index]
    S["tclbV_better_from_learned"] = int(sum(tv.loc[k, "source"] == "learned" for k in better[better].index))
    S["tclbV_source_learned_share"] = float((tv.source == "learned").mean())
    S["uniform_at_takt_bound"] = int((piv["UNIFORM_TUNED"] <= piv["TAKT"]).sum())
    S["better_by_scenario"] = {sc: int(better.xs(sc, level=1).sum()) for sc in sorted(d.scenario.unique())}
    S["better_sources"] = {f"{k[0]}|{k[1]}": tv.loc[k, "source"] for k in better[better].index}
    S["chance_infeasible"] = {m: int(((d.method == m) & d.ops.isna()).sum()) for m in ["CHANCE_90", "CHANCE_95"]}
    S["tclbC_feasible_rate"] = float(d[d.method == "TCLB_C"].feasible.mean())
    json.dump(S, open("results/summary.json", "w"), indent=1)
    print(tab.round(3).to_string()); print(json.dumps({k: v for k, v in S.items() if "vs" in k or k.startswith("equal")}, indent=1))

    # Figure 1: mean operators above the lower bound, by scenario and method
    fig, ax = plt.subplots(figsize=(7.6, 3.5))
    exc = d.pivot_table(index="scenario", columns="method", values="excess", aggfunc="mean").reindex(columns=METHODS)
    scen = list(exc.index); x = np.arange(len(scen)); wbar = 0.115
    for k, m in enumerate(METHODS):
        ax.bar(x + (k - 3) * wbar, exc[m].values, width=wbar - 0.02, color=PAL[k], label=LABEL[m], zorder=3)
    ax.set_xticks(x); ax.set_xticklabels([s.replace("_", "\n") for s in scen])
    ax.set_ylabel("Operators above ⌈work content / takt⌉ (mean)")
    ax.grid(axis="y", color=GRID, zorder=0); ax.spines[["top", "right"]].set_visible(False)
    ax.legend(ncol=3, fontsize=7.5, frameon=False, loc="upper left", bbox_to_anchor=(0, 1.22))
    fig.tight_layout(); fig.savefig("results/fig_operators_by_scenario.png", dpi=300); plt.close(fig)

    # Figure 2: operators vs reliability (LCB/target), all cases
    fig, ax = plt.subplots(figsize=(6.0, 3.6))
    for k, m in enumerate(METHODS):
        s = d[d.method == m]
        ax.scatter(s.excess + (k - 3) * 0.05, s.lcb_ratio, s=22, color=PAL[k], label=LABEL[m],
                   edgecolor="white", linewidth=0.6, zorder=3)
    ax.axhline(1.0, color=INK2, lw=1, ls="--", zorder=2); ax.text(ax.get_xlim()[1], 1.0, " demand", va="center", fontsize=7.5, color=INK2)
    ax.set_xlabel("Operators above lower bound"); ax.set_ylabel("95% LCB of throughput / demand")
    ax.grid(color=GRID, zorder=0); ax.spines[["top", "right"]].set_visible(False)
    ax.legend(fontsize=7, frameon=False, ncol=2, loc="upper left", bbox_to_anchor=(0, 1.25))
    fig.tight_layout(); fig.savefig("results/fig_operators_vs_reliability.png", dpi=300); plt.close(fig)


if __name__ == "__main__":
    main()
