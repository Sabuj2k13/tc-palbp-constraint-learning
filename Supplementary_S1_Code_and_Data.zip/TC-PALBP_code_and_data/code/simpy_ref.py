"""Reference SimPy model (units may overtake inside a duplicated station) used only to
validate the fast recursion in sim.py."""
import numpy as np
import simpy


def simpy_throughput(P, r, b, warm=60.0, horizon=480.0):
    """P: (N,K) processing times, unit n at station k. Returns units leaving the last
    station in (warm, warm+horizon]."""
    N, K = P.shape
    env = simpy.Environment()
    # store between k-1 and k holds units waiting for station k (capacity b);
    # station 0 has an unlimited source.
    buffers = [None] + [simpy.Store(env, capacity=b) for _ in range(K - 1)]
    done = []
    counter = [0]

    def source_take():
        n = counter[0]
        counter[0] += 1
        return n

    def operator(k):
        while True:
            if k == 0:
                n = source_take()
                if n >= N:
                    return
            else:
                n = yield buffers[k].get()
            yield env.timeout(P[n, k])
            if k < K - 1:
                yield buffers[k + 1].put(n)      # blocks while full (BAS)
            else:
                done.append(env.now)

    for k in range(K):
        for _ in range(r[k]):
            env.process(operator(k))
    env.run(until=warm + horizon + 1)
    d = np.array(done)
    return int(((d > warm) & (d <= warm + horizon)).sum())
